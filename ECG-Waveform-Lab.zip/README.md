# ECG-Waveform-Lab

Full repository for simulating and comparing Entropic Coherence Gravity (ECG) waveforms to LIGO data.
